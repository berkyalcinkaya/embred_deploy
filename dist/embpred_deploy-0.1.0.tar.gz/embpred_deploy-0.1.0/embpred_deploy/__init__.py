"""
EmbPred Deploy - A deployment package for running inference using Faster-RCNN and custom classification networks.
"""

__version__ = "0.1.0"
__author__ = "Berk Yalcinkaya"
__email__ = "berkyalc@stanford.edu"

__all__ = []
