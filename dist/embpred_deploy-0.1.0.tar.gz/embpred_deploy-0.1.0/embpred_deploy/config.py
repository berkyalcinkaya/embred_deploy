import os
# add a path to the project
#
PROJ_DIR =  os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(PROJ_DIR, "models")